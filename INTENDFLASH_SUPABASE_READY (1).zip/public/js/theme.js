(function(){
  const key='intendflash_theme';
  const saved=localStorage.getItem(key);
  if(saved==='dark') document.body.classList.add('dark-mode');
  const btn=document.createElement('button');
  btn.type='button';
  btn.className='theme-toggle';
  btn.setAttribute('aria-label','Toggle dark mode');
  btn.title='Toggle dark mode';
  function update(){
    const dark=document.body.classList.contains('dark-mode');
    btn.textContent=dark?'☀':'☾';
    btn.setAttribute('aria-label',dark?'Switch to light mode':'Switch to dark mode');
    btn.title=dark?'Light mode':'Dark mode';
  }
  btn.addEventListener('click',function(){
    document.body.classList.toggle('dark-mode');
    localStorage.setItem(key,document.body.classList.contains('dark-mode')?'dark':'light');
    update();
  });
  document.body.appendChild(btn);
  update();
})();
