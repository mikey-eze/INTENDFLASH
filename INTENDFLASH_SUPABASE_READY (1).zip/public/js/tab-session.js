(function () {
  const KEY = 'intendflash_tab_id';
  let tab = sessionStorage.getItem(KEY);
  if (!tab) {
    tab = (crypto.randomUUID ? crypto.randomUUID() : 'tab-' + Date.now() + '-' + Math.random().toString(36).slice(2));
    sessionStorage.setItem(KEY, tab);
  }
  const url = new URL(window.location.href);
  if (!url.searchParams.get('tab')) {
    url.searchParams.set('tab', tab);
    window.location.replace(url.toString());
    return;
  }
  function addTab() {
    document.querySelectorAll('a[href],form[action]').forEach(el => {
      const attr = el.tagName === 'FORM' ? 'action' : 'href';
      const raw = el.getAttribute(attr);
      if (!raw || raw.startsWith('#') || raw.startsWith('javascript:') || raw.startsWith('http')) return;
      try {
        const u = new URL(raw, window.location.origin);
        if (u.origin !== window.location.origin) return;
        u.searchParams.set('tab', tab);
        el.setAttribute(attr, u.pathname + u.search + u.hash);
      } catch (_) {}
    });
  }
  addTab();
  window.addEventListener('pageshow', addTab);
})();
